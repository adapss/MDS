﻿using System.Collections.Generic;
using System.Data;
 using CommonTools;
using System;



public class ClientsController: ClientsModel

{
 private string _tableName = "Clients";

 public void Delete() 
    {
             if (ClientId  == -1)  return;

            string sql = "exec DeleteClients " + ClientId.ToString();
            CommonTools.DataAccessObject.ExecuteProcedure(sql);
     }


 public bool Save()  
{
  if (ClientId  == -1) 

{
 return Insert();
}
   else
{
      return Update();
 }

}

 public bool Fetch() 
{

 string sql; 

        sql = "Select * From Clients  where ClientId= " + ClientId;
        return Populate(sql);


 }


private bool Populate(string SQL) 
{

         try
{
           DataRow  records = DataAccessObject.GetOneRow(SQL);

             if (records == null) return false;


                ClientId = (int) records["ClientId"];
                ClientName = (records["ClientName"].ToString() == null? "": records["ClientName"].ToString());
                StarDate = (records["StarDate"].ToString() == null? "": records["StarDate"].ToString());
                Active = (int) records["Active"];
                CreateOn = (records["CreateOn"].ToString() == null? "": records["CreateOn"].ToString());
                CreatedBy = (records["CreatedBy"].ToString() == null? "": records["CreatedBy"].ToString());
                ModifiedOn = (records["ModifiedOn"].ToString() == null? "": records["ModifiedOn"].ToString());
                ModifiedBy = (records["ModifiedBy"].ToString() == null? "": records["ModifiedBy"].ToString());


             return true;
}
         catch ( Exception ex)
{
             ErrorManager.LogError("clsClients", "Populate", "", ex);
             return false;
}
         finally
{
             DataAccessObject.CloseConnection();
}


     }

  private List<DatabaseParameter>  CreateParameterList () 
  {
   List<DatabaseParameter> values  = new List<DatabaseParameter>(); 
    if (ClientId == -1)  
  {
    values.Add (new DatabaseParameter("@ClientId",  DbType.Int16,  null,  true));  
  }
  else    
  {
   values.Add(new DatabaseParameter("@ClientId", DbType.Int16, ClientId));  
  }
 
  values.Add (new DatabaseParameter("@ClientName",DbType.String,ClientName)); 
  values.Add (new DatabaseParameter("@StarDate",DbType.String,StarDate)); 
  values.Add (new DatabaseParameter("@Active",DbType.Int32,Active)); 
  values.Add (new DatabaseParameter("@CreateOn",DbType.String,CreateOn)); 
  values.Add (new DatabaseParameter("@CreatedBy",DbType.String,CreatedBy)); 
  values.Add (new DatabaseParameter("@ModifiedOn",DbType.String,ModifiedOn)); 
  values.Add (new DatabaseParameter("@ModifiedBy",DbType.String,ModifiedBy)); 
 
 return values; 
  }


 private bool Insert() 
{
     try
{
         if (ClientId != -1) { return false; }
    DataAccessObject.ExecuteDatabaseTransaction("iClients",CreateParameterList()); 


        return true;
}

     catch (Exception ex )
     {
         ErrorManager.LogError("Clients", "", "Insert", ex);
         return false;
     }

 }



 private bool Update() 
 {
     try
{

    DataAccessObject.ExecuteDatabaseTransaction("uClients",CreateParameterList()); 




        return true;

}
     catch (Exception ex) {
         ErrorManager.LogError("Clients", "", "Update", ex);
         return false;
     }

 }




 } 

