﻿
 public class ClientsModel

{
public ClientsModel()
{

ClientId= -1;
ClientName = "";
StarDate = "";
Active= -1;
CreateOn = "";
CreatedBy = "";
ModifiedOn = "";
ModifiedBy = "";

}
public  int ClientId {get;set;}  
public  string  ClientName {get;set;}  
public  string  StarDate {get;set;}  
public  int Active {get;set;}  
public  string  CreateOn {get;set;}  
public  string  CreatedBy {get;set;}  
public  string  ModifiedOn {get;set;}  
public  string  ModifiedBy {get;set;}  


}

