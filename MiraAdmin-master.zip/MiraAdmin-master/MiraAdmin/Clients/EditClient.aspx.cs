﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using CommonTools;
using MiraAdmin.ClientStudies;
using MiraAdmin.ClientUsers;
using MiraAdmin.WebTools;

namespace MiraAdmin.Clients
{
    public partial class EditClient : System.Web.UI.Page
    {
        ClientsController value;
        private ClientUsersView values = new ClientUsersView();
        private string RedirectFormName = @"..\ClientUsers\EditClientUsers.aspx";

        void PopulateUsers()
        {
            
            dtgUsers.DataSource = values.GetClientUsers(WebTools.WebHelper.CurrentValueId);
            dtgUsers.DataBind();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack) return;

           

            string strScript;
            strScript = " <script language=JavaScript>                             ";
            strScript += " function CheckAll( checkAllBox )                         ";
            strScript += " {                                                                  ";
            strScript += " var frm = document.Form1;                               ";
            strScript += "  var ChkState=checkAllBox.checked;                   ";
            strScript += "  for(i=0;i< frm.length;i++)                                 ";
            strScript += "  {                                                                 ";
            strScript += "         e=frm.elements[i];                                   ";
            strScript += "        if(e.type=='checkbox' && e.name.indexOf('Id') != -1)";
            strScript += "            e.checked= ChkState ;                        ";
            strScript += "  }                                                               ";
            strScript += " }                                                                ";
            strScript += "  </script>                                                     ";
            if (!this.IsClientScriptBlockRegistered("clientScriptCheckAll"))
                RegisterClientScriptBlock("clientScriptCheckAll", strScript);

            strScript = "";
            strScript = "<script language=JavaScript>                              ";
            strScript += "function CheckChanged()                                   ";
            strScript += "{                                                                   ";
            strScript += "  var frm = document.Form1;                              ";
            strScript += "  var boolAllChecked;                                         ";
            strScript += "  boolAllChecked=true;                                       ";
            strScript += "  for(i=0;i< frm.length;i++)                                 ";
            strScript += "  {                                                                 ";
            strScript += "    e=frm.elements[i];                                        ";
            strScript += "  if ( e.type=='checkbox' && e.name.indexOf('Id') != -1 )";
            strScript += "      if(e.checked== false)                                  ";
            strScript += "      {                                                             ";
            strScript += "         boolAllChecked=false;                               ";
            strScript += "         break;                                                    ";
            strScript += "      }                                                              ";
            strScript += "  }                                                                  ";
            strScript += "  for(i=0;i< frm.length;i++)                                  ";
            strScript += "  {                                                                  ";
            strScript += "    e=frm.elements[i];                                         ";
            strScript += "    if ( e.type=='checkbox' && e.name.indexOf('checkAll') != -1 )";
            strScript += "    {                                                            ";
            strScript += "      if( boolAllChecked==false)                         ";
            strScript += "         e.checked= false ;                                ";
            strScript += "         else                                                    ";
            strScript += "         e.checked= true;                                  ";
            strScript += "      break;                                                    ";
            strScript += "    }                                                             ";
            strScript += "   }                                                              ";
            strScript += " }                                                                ";
            strScript += " </script>                                                     ";
            if (!this.IsClientScriptBlockRegistered("clientScriptCheckChanged"))
                this.RegisterClientScriptBlock("clientScriptCheckChanged", strScript);

            PopulateUsers();
            Populate();

        }

        public void SelectItem(object src, DataGridCommandEventArgs e)
        {
            try
            {
                if (e.Item.ItemIndex < 0) return;
                if (e.Item.Cells.Count < 2) return;
                int id = int.Parse(e.Item.Cells[0].Text);
                WebHelper.CurrentValueId = id;
                Response.Redirect(RedirectFormName);
            }
            catch (Exception ex)
            {
                ErrorManager.LogError("EditClients.aspx", "SelectItem", "", ex);

            }

        }

        private void Populate()
        {
            try
            {
                
                value = new ClientsController();
                value.ClientId = WebHelper.CurrentValueId;
                if (!value.Fetch()) return;

                txtClientName.Text = value.ClientName;
                txtStartDate.Text = value.StarDate;
                chActive.SelectedValue = value.Active.ToString();
                PopulateStudies();


            }

            catch (Exception ex)
            {
                ErrorManager.LogError("EditClients", "", "Populate", ex);
                return;
            }



        }

        private List<string> SelectedYears()
        {
            List<string> selection = new List<string>();


            if (chkYears.Items.Count == 0)
            {
                return selection;
            }

            var allChecked = from ListItem li in chkYears.Items
                             where li.Selected == true
                             select li.Value;

            return allChecked.ToList();

        }

        private void PopulateStudies(bool filterYears = false)
        {

            if (WebHelper.CurrentValueId == -1) return;
            ClientStudiesView studies = new ClientStudiesView();

            if (!filterYears)
            {
                chkYears.DataSource = studies.GetStudyYears();
                chkYears.DataTextField = "Year";
                chkYears.DataTextField = "Year";
                chkYears.DataBind();
            }

            dtgData.DataSource = studies.GetAssigned(WebHelper.CurrentValueId, SelectedYears(),txtSearchAssigned.Text);
            dtgData.DataBind();


            dtgUnAssigned.DataSource = studies.GetUnAssigned(WebHelper.CurrentValueId, SelectedYears(), txtSearchUnassigned.Text);
            dtgUnAssigned.DataBind();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                value = new ClientsController();

                value.ClientId = WebTools.WebHelper.CurrentValueId;
                value.ClientName = txtClientName.Text;
                value.StarDate = txtStartDate.Text;
                value.CreatedBy = WebHelper.LoggedInUser;
                value.ModifiedBy = WebHelper.LoggedInUser;
                value.Active = Int32.Parse(chActive.SelectedValue);
               

                if (value.Save())
                {
                    lblInformation.Text = "Record saved";
                }
                else
                {
                    lblInformation.Text = "Unable to save  record";
                }
            }

            catch (Exception ex)
            {
                ErrorManager.LogError("EditClient", "btnSubmit", "Click", ex);
                return;
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("Index.aspx");
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
           // add studies 

          //var allChecked =  from ListItem li in lstUnassigned.Items
          //  where li.Selected == true
          //  select li;


            var allChecked = GetSelectedUnAssignedStudies();
            var selectedYears = SelectedYears();

            foreach(var year in selectedYears)
            {
                foreach (var item in allChecked)
                {
                    ClientStudiesController clientStudiesController = new ClientStudiesController();
                    clientStudiesController.ClientId = WebTools.WebHelper.CurrentValueId;
                    clientStudiesController.BaseYear = Int32.Parse(year);
                    clientStudiesController.StudyId = Int32.Parse(item);
                    clientStudiesController.Save();

                }
            }

           

            PopulateStudies();
          
        }

        public List<string> GetSelectedUnAssignedStudies()
        {
            List<string> selected = new List<string>();


            foreach (DataGridItem di in dtgUnAssigned.Items)
            {
                HtmlInputCheckBox chkBx = (HtmlInputCheckBox)di.FindControl("ItemId");
                if (chkBx != null && chkBx.Checked)
                {
                    Label lbl = (Label)di.FindControl("Id");
                    selected.Add(lbl.Text);
                }
            }

            return selected;
        }


        public List<string> GetSelectedStudies()
        {
            List<string> selected = new List<string>();


            foreach (DataGridItem di in dtgData.Items)
            {
                HtmlInputCheckBox chkBx = (HtmlInputCheckBox)di.FindControl("ItemId");
                if (chkBx != null && chkBx.Checked)
                {
                    Label lbl = (Label)di.FindControl("Id");
                    selected.Add(lbl.Text);
                }
            }

            return selected;
        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
           
            var allChecked = GetSelectedStudies();

            foreach (var item in allChecked)
            {

                ClientStudiesController clientStudiesController = new ClientStudiesController();
                clientStudiesController.id = Int32.Parse(item);
                clientStudiesController.Delete();
            }

            PopulateStudies();
        }

        protected void chkYears_SelectedIndexChanged(object sender, EventArgs e)
        {
            //based on selections, refresh the display
            PopulateStudies(true);

        }

        protected void chkAll_CheckedChanged(object sender, EventArgs e)
        {
            bool checkAll = chkAll.Checked;

            (from i in chkYears.Items.Cast<ListItem>() select i).ToList().ForEach(i => i.Selected = checkAll);
            PopulateStudies(true);

        }

        protected void btnSearchUnassigned_Click(object sender, EventArgs e)
        {
            PopulateStudies(true);
            btnClearUnassigned.Visible = true;
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            value = new ClientsController();
            value.ClientId = WebHelper.CurrentValueId;
            value.Delete();
            Response.Redirect("Index.aspx");

        }

        protected void chkAll_AllUnassigned(object sender, EventArgs e)
        {
            bool status = chkAllUnassigned.Checked;

            foreach (DataGridItem di in dtgUnAssigned.Items)
            {
                HtmlInputCheckBox chkBx = (HtmlInputCheckBox)di.FindControl("ItemId");
                chkBx.Checked = status;
            }
        }

        protected void chkAll_AllAssigned(object sender, EventArgs e)
        {
            bool status = chkAllAssigned.Checked;

            foreach (DataGridItem di in dtgData.Items)
            {
                HtmlInputCheckBox chkBx = (HtmlInputCheckBox)di.FindControl("ItemId");
                chkBx.Checked = status;
            }
        }

        protected void btnClearUnassigned_Click(object sender, EventArgs e)
        {
            txtSearchUnassigned.Text = "";
            btnClearUnassigned.Visible = false;
            PopulateStudies(true);
        }

        protected void btnSearchAssigned_Click(object sender, EventArgs e)
        {
            PopulateStudies(true);
            btnClearAssigned.Visible = true;
        }

        protected void btnClearAssigned_Click(object sender, EventArgs e)
        {
            txtSearchAssigned.Text = "";
            btnClearAssigned.Visible = false;
            PopulateStudies(true);
        }
    }
}