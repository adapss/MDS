﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MiraAdmin.Clients
{
    public class ClientsView
    {
        public List<ClientsModel> list = new List<ClientsModel>();
        public System.Data.DataTable GetView(string searchValue, string orderBy)
        {
            try
            {
                string sql = "SELECT ClientId,ClientName,StarDate,case when Active = 0 then 'No' when Active = 1 then 'Yes' else 'ND' end as Active,CreateOn,CreatedBy,ModifiedOn,ModifiedBy FROM Clients ";
                if (!String.IsNullOrWhiteSpace(searchValue))
                {
                    var isNumeric = int.TryParse(searchValue, out int n);
                    if (!isNumeric)
                    {
                        sql = sql + " and (ClientName like '%" + searchValue + "%')";
                    }
                   

                    if (!String.IsNullOrWhiteSpace(orderBy))
                    {
                        sql = sql + " Order By " + orderBy;
                    }


                }
            
                return CommonTools.DataAccessObject.GetTable(sql);
            }
            catch (Exception ex)
            {
                CommonTools.ErrorManager.LogError("ClientsView", "GetView", "", ex);
                return null;
            }
        }

        public bool PopulateList()
        {
            var data = GetView("","");
            list = new List<ClientsModel>();
            foreach (System.Data.DataRow records in data.Rows)
            {
                ClientsModel newItem = new ClientsModel();
                newItem.ClientId = (int)records["ClientId"];
                newItem.ClientName = (records["ClientName"].ToString() == null ? "" : records["ClientName"].ToString());
                newItem.StarDate = (records["StarDate"].ToString() == null ? "" : records["StarDate"].ToString());
                newItem.Active = (records["Active"].ToString() == "Yes" ? 1:0);
                newItem.CreateOn = (records["CreateOn"].ToString() == null ? "" : records["CreateOn"].ToString());
                newItem.CreatedBy = (records["CreatedBy"].ToString() == null ? "" : records["CreatedBy"].ToString());
                newItem.ModifiedOn = (records["ModifiedOn"].ToString() == null ? "" : records["ModifiedOn"].ToString());
                newItem.ModifiedBy = (records["ModifiedBy"].ToString() == null ? "" : records["ModifiedBy"].ToString());
                list.Add(newItem);
            }
            return true;

        }

    }
}