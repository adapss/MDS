﻿using System;
using CommonTools;

using System.Web;

using System.Web.UI.WebControls;


namespace MiraAdmin.WebTools
{

    public sealed class WebHelper
    {


        //    public static void AddSelectedValue(DropDownList dropDown,Object value) 
        //    {
        //        try
        //        {

        //            if (dropDown.Items.Count == 0) return;


        //            if (value == null || value.ToString().Equals("")) return;


        //            if (dropDown.Items.FindByValue(value.ToString()) != null)
        //                dropDown.SelectedValue = value.ToString();

        //        }
        //    catch(Exception ex)
        //        { }


        //}

        public static string LoggedInUser
        {
            get
            {
                return HttpContext.Current.User.ToString();
            }

        }

        public static void BindControl(DropDownList ctrl, System.Data.DataSet source, string textField, string textValue)
        {
            try
            {
                ctrl.DataSource = source;
                ctrl.DataTextField = textField;
                ctrl.DataValueField = textValue;
                ctrl.DataBind();

                ListItem emptyItem = new ListItem();

                emptyItem.Text = "";
                emptyItem.Value = "0";

                ctrl.Items.Insert(0, emptyItem);
            }
            catch (Exception ex)
            {
                ErrorManager.LogError("WebHelper", "", "BindControl", ex);
            }


        }

        public static void BindControl(DropDownList ctrl, System.Data.DataTable source, string textField, string textValue)
        {
            try
            {
                ctrl.DataSource = source;
                ctrl.DataTextField = textField;
                ctrl.DataValueField = textValue;
                ctrl.DataBind();

                ListItem emptyItem = new ListItem();

                emptyItem.Text = "";
                emptyItem.Value = "0";

                ctrl.Items.Insert(0, emptyItem);
            }
            catch (Exception ex)
            {
                ErrorManager.LogError("WebHelper", "", "BindControl", ex);
            }


        }

        public static string CurrentID
        {
            get
            {
                if (HttpContext.Current.Session["CurrentID"] == null) return "";
                return HttpContext.Current.Session["CurrentID"].ToString(); 
            }
            set
            {
                if (String.IsNullOrEmpty(value)) value = "";
                HttpContext.Current.Session["CurrentID"] = value;

                

            }

        }

        public static int CurrentValueId
        {
            get
            {
                if (HttpContext.Current.Session["CurrentID"] == null) return -1;
                return int.Parse( HttpContext.Current.Session["CurrentID"].ToString());
            }
            set
            {
                if (value == 0) value = -1;
                HttpContext.Current.Session["CurrentID"] = value;



            }

        }
      

        public static void AddSelectedValue(DropDownList dropDown, object value)
        {
            try
            {



                if (dropDown.Items.Count == 0) return;


                if (value == null | value.ToString().Equals("")) return;


                if (dropDown.Items.FindByValue(value.ToString()) != null)
                {
                    dropDown.SelectedValue = value.ToString();
                }

            }

            catch (Exception ex)
            { }



        }
    }
}