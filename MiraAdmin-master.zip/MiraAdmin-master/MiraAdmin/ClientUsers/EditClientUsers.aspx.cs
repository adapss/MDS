﻿using CommonTools;
using MiraAdmin.Clients;
using MiraAdmin.WebTools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MiraAdmin.ClientUsers
{
    public partial class EditClientUsers : System.Web.UI.Page
    {
        ClientUsersController value;
        List<ClientsModel> clientList;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack) return;
            Populate();

        }

        private void Populate()
        {
            try
            {


                clientList = new List<ClientsModel>();
                ClientsView clients = new ClientsView();
                if (clients.PopulateList())
                    clientList = clients.list;

                WebTools.WebHelper.BindControl(ddlClients, clients.GetView("",""), "ClientName", "ClientId");
                value = new ClientUsersController();
                value.UserId = WebHelper.CurrentValueId;
                if (!value.Fetch()) return;

                WebTools.WebHelper.AddSelectedValue(ddlClients, value.ClientId);
                txtPrincipalUser.Text = value.PrincipalUser;
                txtStartDate.Text = value.StartDate;
                chActive.SelectedValue = value.Active.ToString();
                txtEndDate.Text = value.EndDate;

            }

            catch (Exception ex)
            {
                ErrorManager.LogError("EditClients", "", "Populate", ex);
                return;
            }



        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                value = new ClientUsersController();

                value.ClientId =  Int32.Parse(  ddlClients.SelectedValue);
                value.UserId = WebTools.WebHelper.CurrentValueId;
                value.PrincipalUser = txtPrincipalUser.Text;
                value.StartDate = txtStartDate.Text;
                value.EndDate = txtEndDate.Text;
                value.CreatedBy = WebHelper.LoggedInUser;
                value.ModifiedBy = WebHelper.LoggedInUser;
                value.Active = Int32.Parse(chActive.SelectedValue);


                if (value.Save())
                {
                    lblInformation.Text = "Record saved";
                }
                else
                {
                    lblInformation.Text = "Unable to save  record";
                }
            }

            catch (Exception ex)
            {
                ErrorManager.LogError("EditClientUser", "btnSubmit", "Click", ex);
                return;
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("Index.aspx");
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            value = new ClientUsersController();

            
            value.UserId = WebTools.WebHelper.CurrentValueId;
            value.Fetch();
            value.Delete();
            Response.Redirect("Index.aspx");
        }
    }
}