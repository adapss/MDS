﻿
 public class ClientUsersModel

{
public ClientUsersModel()
{

UserId= -1;
ClientId= -1;
PrincipalUser = "";
Active= -1;
StartDate = "";
EndDate = "";
CreatedOn = "";
CreatedBy = "";
ModifiedOn = "";
ModifiedBy = "";

}
public  int UserId {get;set;}  
public  int ClientId {get;set;}  
public  string  PrincipalUser {get;set;}  
public  int Active {get;set;}  
public  string  StartDate {get;set;}  
public  string  EndDate {get;set;}  
public  string  CreatedOn {get;set;}  
public  string  CreatedBy {get;set;}  
public  string  ModifiedOn {get;set;}  
public  string  ModifiedBy {get;set;}  


}

