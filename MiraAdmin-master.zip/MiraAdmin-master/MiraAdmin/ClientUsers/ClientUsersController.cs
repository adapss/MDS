﻿using System.Collections.Generic;
using System.Data;
using CommonTools;
using System;

public class ClientUsersController: ClientUsersModel

{
 private string _tableName = "ClientUsers";

 public void Delete() 

{
  if (UserId  == -1)  return; 

 DataAccessObject.Execute("Delete From  ClientUsers where Userid = " +  UserId);

 }


 public bool Save()  
{
  if (UserId  == -1) 

{
 return Insert();
}
   else
{
      return Update();
 }

}

 public bool Fetch() 
{

 string sql; 

        sql = "Select * From ClientUsers  where UserId= " + UserId;
        return Populate(sql);


 }


private bool Populate(string SQL) 
{

         try
{
           DataRow  records = DataAccessObject.GetOneRow(SQL);

             if (records == null) return false;


    UserId = (int) records["UserId"];
    ClientId = (int) records["ClientId"];
    PrincipalUser = (records["PrincipalUser"].ToString() == null? "": records["PrincipalUser"].ToString());
    Active = (int) records["Active"];
    StartDate = (records["StartDate"].ToString() == null? "": records["StartDate"].ToString());
    EndDate = (records["EndDate"].ToString() == null? "": records["EndDate"].ToString());
    CreatedOn = (records["CreatedOn"].ToString() == null? "": records["CreatedOn"].ToString());
    CreatedBy = (records["CreatedBy"].ToString() == null? "": records["CreatedBy"].ToString());
    ModifiedOn = (records["ModifiedOn"].ToString() == null? "": records["ModifiedOn"].ToString());
    ModifiedBy = (records["ModifiedBy"].ToString() == null? "": records["ModifiedBy"].ToString());


             return true;
}
         catch ( Exception ex)
{
             ErrorManager.LogError("clsClientUsers", "Populate", "", ex);
             return false;
}
         finally
{
             DataAccessObject.CloseConnection();
}


     }

  private List<DatabaseParameter>  CreateParameterList () 
  {
   List<DatabaseParameter> values  = new List<DatabaseParameter>(); 
    if (ClientId == -1)  
  {
    values.Add (new DatabaseParameter("@UserId",  DbType.Int16,  null,  true));  
  }
  else    
  {
   values.Add(new DatabaseParameter("@UserId", DbType.Int16, UserId));  
  }
 
  values.Add (new DatabaseParameter("@ClientId",DbType.Int32,ClientId)); 
  values.Add (new DatabaseParameter("@PrincipalUser",DbType.String,PrincipalUser)); 
  values.Add (new DatabaseParameter("@Active",DbType.Int32,Active)); 
  values.Add (new DatabaseParameter("@StartDate",DbType.String,StartDate)); 
  values.Add (new DatabaseParameter("@EndDate",DbType.String,EndDate)); 
  values.Add (new DatabaseParameter("@CreatedOn",DbType.String,CreatedOn)); 
  values.Add (new DatabaseParameter("@CreatedBy",DbType.String,CreatedBy)); 
  values.Add (new DatabaseParameter("@ModifiedOn",DbType.String,ModifiedOn)); 
  values.Add (new DatabaseParameter("@ModifiedBy",DbType.String,ModifiedBy)); 
 
 return values; 
  }


 private bool Insert() 
{
     try
{
         if (UserId != -1) { return false; }
    DataAccessObject.ExecuteDatabaseTransaction("iClientUsers",CreateParameterList()); 


        return true;
}

     catch (Exception ex )
     {
         ErrorManager.LogError("ClientUsers", "", "Insert", ex);
         return false;
     }

 }



 private bool Update() 
 {
     try
{

    DataAccessObject.ExecuteDatabaseTransaction("uClientUsers",CreateParameterList()); 




        return true;

}
     catch (Exception ex) {
         ErrorManager.LogError("ClientUsers", "", "Update", ex);
         return false;
     }

 }




 } 

