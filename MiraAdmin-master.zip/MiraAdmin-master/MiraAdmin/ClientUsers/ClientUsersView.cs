﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MiraAdmin.ClientUsers
{
    public class ClientUsersView
    {
        public System.Data.DataTable GetClientUsers(int clientId)
        {
            try
            {
                string sql = "SELECT UserId,PrincipalUser,case when Active <> 1 then 'No' else 'Yes' end as Active,StartDate,EndDate,CreatedOn,CreatedBy,ModifiedOn,ModifiedBy FROM ClientUsers Where ClientId =" + clientId.ToString();
               

                return CommonTools.DataAccessObject.GetTable(sql);
            }
            catch (Exception ex)
            {
                CommonTools.ErrorManager.LogError("ClientsView", "GetClientUsers", "", ex);
                return null;
            }

        }

        public System.Data.DataTable GetView(string searchValue, string orderBy)
        {
            try
            {
                string sql = "SELECT UserId,PrincipalUser,(Select ClientName from clients where clientid = ClientUsers.ClientId) as ClientName,case when Active <> 1 then 'No' else 'Yes' end as Active,StartDate,EndDate,CreatedOn,CreatedBy,ModifiedOn,ModifiedBy FROM ClientUsers ";
                if (!String.IsNullOrWhiteSpace(searchValue))
                {
                    var isNumeric = int.TryParse(searchValue, out int n);
                    if (!isNumeric)
                    {
                        sql = sql + " and (PrincipalUser like '%" + searchValue + "%')";
                    }


                    if (!String.IsNullOrWhiteSpace(orderBy))
                    {
                        sql = sql + " Order By " + orderBy;
                    }


                }

                return CommonTools.DataAccessObject.GetTable(sql);
            }
            catch (Exception ex)
            {
                CommonTools.ErrorManager.LogError("ClientsView", "GetView", "", ex);
                return null;
            }
        }
    }
}