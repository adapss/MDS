﻿using MiraAdmin.WebTools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MiraAdmin.Currencies
{
    public partial class EditCurrency : System.Web.UI.Page
    {
        CurrenciesController currency;


        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack) return;
            Populate();

        }

        private void Populate()
        {
            currency = new CurrenciesController();
            currency.CurrencySymbol = WebHelper.CurrentID;
            if (!currency.Fetch()) return;

            txtCurrencyNane.Text = currency.Currency;
            txtCurrencySymbol.Text = currency.CurrencySymbol;


        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            currency = new CurrenciesController();
            currency.CurrencySymbol = txtCurrencySymbol.Text;
            currency.Currency = txtCurrencyNane.Text;
            if (currency.Save())
            {
                lblInformation.Text = "Record saved";
            }
            else
            {
                lblInformation.Text = "Unable to save  record";
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("Index.aspx");
        }
    }
}