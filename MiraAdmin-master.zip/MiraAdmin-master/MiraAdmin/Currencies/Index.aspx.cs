﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CommonTools;
using MiraAdmin.WebTools;


namespace CurrencyMaintenance.Currencies
{
    public partial class Index : System.Web.UI.Page
    {
        private CurrenciesView currencies = new CurrenciesView();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                ProcessLoadData();
            }
        }



        public string SortOrder(string field)
        {
            string so = (ViewState["SortExp"] == null ? "" : ViewState["SortExp"].ToString());


            if (field == so)
            {
                field = so.Contains("asc") ? field.Replace("asc", "desc") : field.Replace("desc", "asc");
            }

            return field;


        }

        void RefreshData()
        {

            try
            {
                WebHelper.CurrentID = "";
                dtgData.DataSource = currencies.GetCurrencies();
                dtgData.DataBind();
            }
            catch (Exception ex)
            {
                ErrorManager.LogError("Default.aspx", "RefreshQuestions", "", ex);

            }
        }

        private void ProcessLoadData()
        {


            try

            {
              


                RefreshData();


            }
            catch (Exception ex)
            {
                ErrorManager.LogError("Default.aspx", "Populate", "", ex);

            }


        }
        public void SortGrid(object source, DataGridSortCommandEventArgs e)
        {
            // System.Web.UI.WebControls.DataGridColumn dgColumn;
            // System.Web.UI.WebControls.DataGridColumn dgColumn;
            string sortDirection;

            dtgData.CurrentPageIndex = 0;
            sortDirection = SortOrder(e.SortExpression);



            foreach (System.Web.UI.WebControls.DataGridColumn dgColumn in dtgData.Columns)
            {
                if (dgColumn.SortExpression == e.SortExpression)
                {
                    if (sortDirection.Contains("desc"))
                    {
                        dgColumn.HeaderText = GeneralTools.StripImageFromHeader(dgColumn.HeaderText);
                        dgColumn.HeaderText += "&nbsp;<img src='../images/arrow_down.gif' style='height=5px;width=auto;' border='0'>";
                    }
                    if (sortDirection.Contains("asc"))
                    {
                        dgColumn.HeaderText = GeneralTools.StripImageFromHeader(dgColumn.HeaderText);
                        dgColumn.HeaderText += "&nbsp;<img src='../images/arrow_up.gif' style='height=5px;width=auto;' border='0'>";
                    }
                    dgColumn.SortExpression = sortDirection;

                }
                else
                {
                    dgColumn.HeaderText = GeneralTools.StripImageFromHeader(dgColumn.HeaderText);
                }

                var parameter = (ViewState["Parameter"] == null ? "" : ViewState["Parameter"].ToString());
                var parameterValue = (ViewState["ParameterValue"] == null ? "" : ViewState["ParameterValue"].ToString());
                ReBind(sortDirection, parameter, parameterValue);
            }
        }




        public void NavigatePage(object sender, DataGridPageChangedEventArgs args)
        {
            dtgData.CurrentPageIndex = args.NewPageIndex;
            ReBind(ViewState["SortExp"].ToString(), ViewState["Parameter"].ToString(), ViewState["ParameterValue"].ToString());

        }



        public void ReBind(string sortField, string parameter, string value)
        {
            ViewState["SortExp"] = sortField;
            ViewState["Parameter"] = parameter;
            ViewState["ParameterValue"] = value;

            
            dtgData.DataSource = currencies.GetCurrencies();


            try

            {
                dtgData.DataBind();
            }

            catch (Exception ex)
            {
                try
                {
                    if (dtgData.CurrentPageIndex > dtgData.PageCount)
                    {
                        dtgData.CurrentPageIndex = 0;
                        dtgData.DataBind();
                    }
                }
                catch (Exception e1x)
                { }

            }

            //TODO: Implement this labels
            //  lbRemoveFilter.Visible = true;
            //  lblInformation.Visible = false;

        }

        protected void btnNew_Click(object sender, EventArgs e)
        {
            WebHelper.CurrentID = "";
            Response.Redirect("EditCurrency.aspx");
        }

       
        public void SelectItem(object src, DataGridCommandEventArgs e)
        {
            if (e.Item.ItemIndex < 0) return;
            if (e.Item.Cells.Count < 2) return;
            string id = e.Item.Cells[0].Text;
            WebHelper.CurrentID = id;
            Response.Redirect("EditCurrency.aspx");
          



        }

      
    }
}
