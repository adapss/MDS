﻿
 public class CurrenciesModel

{
        public CurrenciesModel()
        {

        Currency = "";
        CurrencySymbol = "";

        }

    public bool IsCurrencyValid
    {
        get
        {
            if (string.IsNullOrEmpty(CurrencySymbol)) return false;
            if (string.IsNullOrWhiteSpace(CurrencySymbol)) return false;
            return true;

        }

     }
        public  string  Currency {get;set;}  
        public  string  CurrencySymbol {get;set;}  


}

