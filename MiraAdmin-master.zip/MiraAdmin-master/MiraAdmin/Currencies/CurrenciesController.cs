﻿using System;
using System.Collections.Generic;
using System.Data;

 using CommonTools;




 public class CurrenciesController: CurrenciesModel

{
         private string _tableName = "Currencies";

         public void Delete() 

        {
          if (IsCurrencyValid == false)  return; 

         DataAccessObject.Execute("Delete From " + _tableName + " where CurrencySymbol = '" + CurrencySymbol + "'");

         }


    private bool RecordExists()
    {
        var record = DataAccessObject.GetOneRow( "Select * From " + _tableName + "  where CurrencySymbol= '" + CurrencySymbol + "'");
        if (record == null) return false;
        return true;
    }


         public bool Save()  
        {
          if (RecordExists() == false) 

        {
         return Insert();
        }
           else
        {
              return Update();
         }

        }

         public bool Fetch() 
        {

         string sql;

                sql = "Select * From " + _tableName + "  where CurrencySymbol= '" + CurrencySymbol + "'";
                return Populate(sql);


         }


        private bool Populate(string SQL) 
        {

                 try
        {
                   DataRow  records = DataAccessObject.GetOneRow(SQL);

                     if (records == null) return false;


            Currency = (records["Currency"].ToString() == null? "": records["Currency"].ToString());
            CurrencySymbol = (records["CurrencySymbol"].ToString() == null? "": records["CurrencySymbol"].ToString());


                     return true;
        }
                 catch (System.Exception ex)
        {
                     ErrorManager.LogError("Currencies", "Populate", "", ex);
                     return false;
        }
                 finally
        {
                     DataAccessObject.CloseConnection();
        }


             }

          private List<DatabaseParameter>  CreateParameterList () 
          {
           List<DatabaseParameter> values  = new List<DatabaseParameter>(); 
   

                values.Add(new DatabaseParameter("@Currency", DbType.String, Currency));
                values.Add (new DatabaseParameter("@CurrencySymbol",DbType.String,CurrencySymbol)); 
 
         return values; 
          }


         private bool Insert() 
        {
             try
        {
         
            DataAccessObject.ExecuteDatabaseTransaction("i"  + _tableName , CreateParameterList()); 


                return true;
        }

             catch (Exception ex )
             {
                 ErrorManager.LogError("Currencies", "", "Insert", ex);
                 return false;
             }

         }



         private bool Update() 
         {
             try
        {

            DataAccessObject.ExecuteDatabaseTransaction("u" + _tableName, CreateParameterList()); 

                return true;

        }
             catch (Exception ex) {
                 ErrorManager.LogError("Currencies", "", "Update", ex);
                 return false;
             }

         }




 } 

