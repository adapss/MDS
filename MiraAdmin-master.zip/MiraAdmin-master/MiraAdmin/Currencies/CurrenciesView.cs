﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CommonTools;


namespace CurrencyMaintenance.Currencies
{
    public class CurrenciesView
    {

        public List<CurrenciesModel> list = new List<CurrenciesModel>();
        public System.Data.DataTable GetCurrencies ()
        {
            return CommonTools.DataAccessObject.GetTable("Select * From Currencies Order by Currency");
        }

        public bool PopulateList()
        {
            var data = GetCurrencies();
            list = new List<CurrenciesModel>();
            foreach (System.Data.DataRow records in data.Rows)
            {
                CurrenciesModel newItem = new CurrenciesModel();
                newItem.Currency = (records["Currency"].ToString() == null ? "" : records["Currency"].ToString());
                newItem.CurrencySymbol = (records["CurrencySymbol"].ToString() == null ? "" : records["CurrencySymbol"].ToString());
                list.Add(newItem);
            }
            return true;

        }

    }
}