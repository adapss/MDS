﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MiraAdmin.StudyGroup
{
    public class StudyGroupView
    {

        public List<StudyGroupModel> list = new List<StudyGroupModel>();
        public System.Data.DataTable GetGroups()
        {
            return CommonTools.DataAccessObject.GetTable("Select * From StudyGroup Order by GroupName");
        }

        public bool PopulateList()
        {
            var data = GetGroups();
            list = new List<StudyGroupModel>();
            foreach (System.Data.DataRow records in data.Rows)
            {
                StudyGroupModel newItem = new StudyGroupModel();
                newItem.Id = int.Parse( records["Id"].ToString());
                newItem.GroupName = (records["GroupName"].ToString() == null ? "" : records["GroupName"].ToString());
                list.Add(newItem);
            }
            return true;

        }
    }
}