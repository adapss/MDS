﻿
 public class StudyGroupModel

{
public StudyGroupModel()
{

Id= -1;
GroupName = "";

}
public  int Id {get;set;}  
public  string  GroupName {get;set;}  


}

