﻿ using System.Data;


using System;

using CommonTools;
using System.Collections.Generic;

public class StudyGroupController: StudyGroupModel

{
 private string _tableName = "StudyGroup";

 public void Delete() 

{
  if (Id  == -1)  return; 

 DataAccessObject.Execute("Delete From  StudyGroup where id = " +  Id);

 }


 public bool Save()  
{
  if (Id  == -1) 

{
 return Insert();
}
   else
{
      return Update();
 }

}

 public bool Fetch() 
{

 string sql; 

        sql = "Select * From StudyGroup  where Id= " + Id;
        return Populate(sql);


 }


private bool Populate(string SQL) 
{

         try
{
           DataRow  records = DataAccessObject.GetOneRow(SQL);

             if (records == null) return false;


    Id = (int) records["Id"];
    GroupName = (records["GroupName"].ToString() == null? "": records["GroupName"].ToString());


             return true;
}
         catch ( Exception ex)
{
             ErrorManager.LogError("clsStudyGroup", "Populate", "", ex);
             return false;
}
         finally
{
             DataAccessObject.CloseConnection();
}


     }

  private List<DatabaseParameter>  CreateParameterList () 
  {
   List<DatabaseParameter> values  = new List<DatabaseParameter>(); 
    if (Id == -1)  
  {
    values.Add (new DatabaseParameter( "@Id",  DbType.Int16,  null,  true));  
  }
  else    
  {
   values.Add(new DatabaseParameter("@Id", DbType.Int16, Id));  
  }
 
  values.Add (new DatabaseParameter("@GroupName",DbType.String,GroupName)); 
 
 return values; 
  }


 private bool Insert() 
{
     try
{
         if (Id != -1) { return false; }
    DataAccessObject.ExecuteDatabaseTransaction("iStudyGroup",CreateParameterList()); 


        return true;
}

     catch (Exception ex )
     {
         ErrorManager.LogError("StudyGroup", "", "Insert", ex);
         return false;
     }

 }



 private bool Update() 
 {
     try
{

    DataAccessObject.ExecuteDatabaseTransaction("uStudyGroup",CreateParameterList()); 




        return true;

}
     catch (Exception ex) {
         ErrorManager.LogError("StudyGroup", "", "Update", ex);
         return false;
     }

 }




 } 

