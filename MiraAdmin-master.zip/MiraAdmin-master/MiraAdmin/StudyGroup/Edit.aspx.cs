﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MiraAdmin.WebTools;

namespace MiraAdmin.StudyGroup
{
    public partial class Edit : System.Web.UI.Page
    {
        StudyGroupController studyGroup;


        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack) return;
            Populate();

        }

        private void Populate()
        {
            studyGroup = new StudyGroupController();
            studyGroup.Id = WebHelper.CurrentValueId;
            if (!studyGroup.Fetch()) return;

            txtValue.Text = studyGroup.GroupName;
            

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            studyGroup = new StudyGroupController();
            studyGroup.Id = WebHelper.CurrentValueId;
            studyGroup.GroupName = txtValue.Text;
           
            if (studyGroup.Save())
            {
                lblInformation.Text = "Record saved";
            }
            else
            {
                lblInformation.Text = "Unable to save record";
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("Index.aspx");
        }
    }
}