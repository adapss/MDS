﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CommonTools;
using MiraAdmin.WebTools;

namespace MiraAdmin.CurrencyValues
{
    public partial class Index : System.Web.UI.Page
    {
        private CurrecyValuesView values = new CurrecyValuesView();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                ProcessLoadData();
            }
        }



        public string SortOrder(string field)
        {
            try { 

            string so = (ViewState["SortExp"] == null ? "" : ViewState["SortExp"].ToString());


            if (field == so)
            {
                field = so.Contains("asc") ? field.Replace("asc", "desc") : field.Replace("desc", "asc");
            }

            return field;
            }

            catch (Exception ex)
            {
                ErrorManager.LogError("Index", "SortOrder", "", ex);
                return "";
            }


        }

        void RefreshData()
        {

            try
            {
                WebHelper.CurrentValueId = -1;
                dtgData.DataSource = values.GetCurrencies(txtSurveyName.Text,SortExp);
                dtgData.DataBind();
            }
            catch (Exception ex)
            {
                ErrorManager.LogError("Default.aspx", "RefreshQuestions", "", ex);

            }
        }

        private void ProcessLoadData()
        {


            try

            {



                RefreshData();


            }
            catch (Exception ex)
            {
                ErrorManager.LogError("Index.aspx", "RefreshData", "", ex);

            }


        }
        public void SortGrid(object source, DataGridSortCommandEventArgs e)
        {
            try
            {
                // System.Web.UI.WebControls.DataGridColumn dgColumn;
                string sortDirection;

                dtgData.CurrentPageIndex = 0;
                sortDirection = SortOrder(e.SortExpression);



                foreach (System.Web.UI.WebControls.DataGridColumn dgColumn in dtgData.Columns)
                {
                    if (dgColumn.SortExpression == e.SortExpression)
                    {
                        if (sortDirection.Contains("desc"))
                        {
                            dgColumn.HeaderText = GeneralTools.StripImageFromHeader(dgColumn.HeaderText);
                            dgColumn.HeaderText += "&nbsp;<img src='../images/arrow_down.gif' style='height=5px;width=auto;' border='0'>";
                        }
                        if (sortDirection.Contains("asc"))
                        {
                            dgColumn.HeaderText = GeneralTools.StripImageFromHeader(dgColumn.HeaderText);
                            dgColumn.HeaderText += "&nbsp;<img src='../images/arrow_up.gif' style='height=5px;width=auto;' border='0'>";
                        }
                        dgColumn.SortExpression = sortDirection;

                    }
                    else
                    {
                        dgColumn.HeaderText = GeneralTools.StripImageFromHeader(dgColumn.HeaderText);
                    }

                    var parameter = (ViewState["Parameter"] == null ? "" : ViewState["Parameter"].ToString());
                    var parameterValue = (ViewState["ParameterValue"] == null ? "" : ViewState["ParameterValue"].ToString());
                    ReBind(sortDirection, parameter, parameterValue);
                }
            
            }
            catch (Exception ex)
            {
                ErrorManager.LogError("Index.aspx", "SortGrid", "", ex);

            }
        }



        private string SortExp
        {
            get
            {
                if (ViewState["SortExp"] != null)
                    return ViewState["SortExp"].ToString();

                return "";
            }
            set
            {
                ViewState["SortExp"] = value;
            }
           
        }
        public void NavigatePage(object sender, DataGridPageChangedEventArgs args)
        {
            try
            { 
            dtgData.CurrentPageIndex = args.NewPageIndex;
            ReBind(SortExp, ViewState["Parameter"].ToString(), ViewState["ParameterValue"].ToString());
            }
            catch (Exception ex)
            {
                ErrorManager.LogError("Index.aspx", "NavigatePage", "", ex);

            }
        }



        public void ReBind(string sortField, string parameter, string value)
        {
           SortExp = sortField;
            ViewState["Parameter"] = parameter;
            ViewState["ParameterValue"] = value;


            dtgData.DataSource = values.GetCurrencies(txtSurveyName.Text,SortExp);


            try

            {
                dtgData.DataBind();
            }

            catch (Exception ex)
            {
                try
                {
                    if (dtgData.CurrentPageIndex > dtgData.PageCount)
                    {
                        dtgData.CurrentPageIndex = 0;
                        dtgData.DataBind();
                    }
                }
                catch (Exception e1x)
                { }

            }

            //TODO: Implement this labels
            //  lbRemoveFilter.Visible = true;
            //  lblInformation.Visible = false;

        }

        protected void btnNew_Click(object sender, EventArgs e)
        {
            WebHelper.CurrentValueId = -1;
            Response.Redirect("EditCurrencyValue.aspx");
        }


        public void SelectItem(object src, DataGridCommandEventArgs e)
        {
            try
            { 
            if (e.Item.ItemIndex < 0) return;
            if (e.Item.Cells.Count < 2) return;
            int id = int.Parse(e.Item.Cells[0].Text);
            WebHelper.CurrentValueId = id;
            Response.Redirect("EditCurrencyValue.aspx");
            }
            catch (Exception ex)
            {
                ErrorManager.LogError("Index.aspx", "SelectItem", "", ex);

            }

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            RefreshData();
        }
    }
}