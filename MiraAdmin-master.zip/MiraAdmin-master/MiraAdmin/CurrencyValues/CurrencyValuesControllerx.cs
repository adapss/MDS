﻿using System;
using System.Collections.Generic;
using System.Data;

 using CommonTools;




 public class CurrencyValuesController: CurrencyValuesModel

{
 private string _tableName = "CurrencyValues";

 public void Delete() 

{
  if (IsCurrencyValid == false)  return; 

 DataAccessObject.Execute("Delete From  " + _tableName + " where id = '" +  CurrencySymbol + "'");

 }


 public bool Save()  
{
  if (IsCurrencyValid == false) 

{
 return Insert();
}
   else
{
      return Update();
 }

}

 public bool Fetch() 
{

 string sql; 

        sql = "Select * From " + _tableName + "  where CurrencySymbol= '" + CurrencySymbol + "'";
        return Populate(sql);


 }


private bool Populate(string SQL) 
{

         try
{
           DataRow  records = DataAccessObject.GetOneRow(SQL);

             if (records == null) return false;


    CurrencySymbol = (records["CurrencySymbol"].ToString() == null? "": records["CurrencySymbol"].ToString());
    Year = (int) records["Year"];
    Value =  double.Parse(records["Value"].ToString());


             return true;
}
         catch ( Exception ex)
{
             ErrorManager.LogError("clsCurrencyValues", "Populate", "", ex);
             return false;
}
         finally
{
             DataAccessObject.CloseConnection();
}


     }

      private List<DatabaseParameter>  CreateParameterList () 
      {
           List<DatabaseParameter> values  = new List<DatabaseParameter>(); 
   
           values.Add(new DatabaseParameter("CurrencySymbol", DbType.Int16, CurrencySymbol));  
  
 
          values.Add (new DatabaseParameter("@Year",DbType.Int32,Year)); 
          values.Add (new DatabaseParameter("@Value",DbType.Double,Value)); 
 
         return values; 
      }


 private bool Insert() 
{
     try
{
        
        DataAccessObject.ExecuteDatabaseTransaction("iCurrencyValues",CreateParameterList()); 


        return true;
}

     catch (Exception ex )
     {
         ErrorManager.LogError("CurrencyValues", "", "Insert", ex);
         return false;
     }

 }



 private bool Update() 
 {
     try
{

    DataAccessObject.ExecuteDatabaseTransaction("uCurrencyValues",CreateParameterList()); 




        return true;

}
     catch (Exception ex) {
         ErrorManager.LogError("CurrencyValues", "", "Update", ex);
         return false;
     }

 }




 } 

