﻿
 public class CurrencyValuesModel

{
        public CurrencyValuesModel()
        {

                id= -1;
                CurrencySymbol = "";
                Year= -1;
                Value= -1;

        }
        public  int id {get;set;}  
        public  string  CurrencySymbol {get;set;}  
        public  int Year {get;set;}  
        public  double  Value {get;set;}  


}

