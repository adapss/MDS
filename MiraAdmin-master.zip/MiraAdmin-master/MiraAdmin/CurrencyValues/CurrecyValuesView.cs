﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MiraAdmin.CurrencyValues
{
    public class CurrecyValuesView
    {

        public System.Data.DataTable GetCurrencies(string searchValue, string orderBy)
        {
            try
            {
                string sql = "select Id,Currency,v.CurrencySymbol,v.year,v.value from Currencies c, CurrencyValues v where c.CurrencySymbol = v.CurrencySymbol";
                if (!String.IsNullOrWhiteSpace(searchValue))
                {
                    var isNumeric = int.TryParse(searchValue, out int n);
                    if (!isNumeric)
                    {
                        sql = sql + " and (Currency like '%" + searchValue + "%' or v.CurrencySymbol like '%" + searchValue + "%')";
                    }
                    else
                    {
                        sql = sql + " and year = " + searchValue;
                    }

                    if (!String.IsNullOrWhiteSpace(orderBy))
                    {
                        sql = sql + " Order By " + orderBy;
                    }
                }
                else
                {
                    sql = sql + " Order by Year desc,Currency";
                }

                return CommonTools.DataAccessObject.GetTable(sql);
            }
            catch(Exception ex)
            {
                CommonTools.ErrorManager.LogError("CurrencyValuesView", "GetCurrencies", "", ex);
                return null;
            }
        }

    }
}