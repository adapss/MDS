﻿
 public class CurrencyValuesModel

{
public CurrencyValuesModel()
{

CurrencySymbol = "";
Year= -1;
Value= -1;

}

    public int Id { get; set; }
    public  string  CurrencySymbol {get;set;}  
    public  int Year {get;set;}  
    public  double  Value {get;set;}



    public bool IsCurrencyValid
    {
        get
        {
            if (string.IsNullOrEmpty(CurrencySymbol)) return false;
            if (string.IsNullOrWhiteSpace(CurrencySymbol)) return false;
            return true;

        }

    }
}

