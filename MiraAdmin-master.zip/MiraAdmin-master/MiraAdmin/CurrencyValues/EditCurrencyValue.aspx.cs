﻿using MiraAdmin.WebTools;
using CurrencyMaintenance.Currencies;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using CommonTools;
namespace MiraAdmin.CurrencyValues
{
    public partial class EditCurrencyValue : System.Web.UI.Page
    {
        CurrencyValuesController value;
        List<CurrenciesModel> currencyList;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack) return;
            Populate();

        }

        private void Populate()
        {
            try { 
                    currencyList = new List<CurrenciesModel>();
                    CurrenciesView currencies = new CurrenciesView();
                    if (currencies.PopulateList())
                        currencyList = currencies.list;

                    WebTools.WebHelper.BindControl(ddlCurrency, currencies.GetCurrencies(), "Currency", "CurrencySymbol");
                    value = new CurrencyValuesController();
                    value.id = WebHelper.CurrentValueId;
                    if (!value.Fetch()) return;

                    WebTools.WebHelper.AddSelectedValue(ddlCurrency, value.CurrencySymbol);
                    txtValue.Text = value.Value.ToString();
                    txtYear.Text = value.Year.ToString();
            }

            catch (Exception ex)
            {
                ErrorManager.LogError("EditCurrencyValue", "", "Populate", ex);
                return ;
            }



        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            { 
                value = new CurrencyValuesController();

                value.id = WebTools.WebHelper.CurrentValueId;
                value.CurrencySymbol = ddlCurrency.SelectedValue;
                value.Year = int.Parse(txtYear.Text);
                value.Value = Double.Parse(txtValue.Text);
          
                if (value.Save())
                {
                    lblInformation.Text = "Record saved";
                }
                else
                {
                    lblInformation.Text = "Unable to save  record";
                }
            }

            catch (Exception ex)
            {
                ErrorManager.LogError("EditCurrencyValue", "btnSubmit", "Click", ex);
                return;
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("Index.aspx");
        }
    }
}