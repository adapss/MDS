﻿using System;
using System.Collections.Generic;
using System.Data;
 using CommonTools;


public class CurrencyValuesController: CurrencyValuesModel

{
 private string _tableName = "CurrencyValues";

 public void Delete() 

{
        try { 
  if (id  == -1)  return; 

 DataAccessObject.Execute("Delete From  CurrencyValues where id = " +  id);

        }
        catch (Exception ex)
        {
            CommonTools.ErrorManager.LogError("CurrencyValuesController", "Delete", "", ex);
            return;
        }
    }


 public bool Save()  
{
  if (id  == -1) 

{
 return Insert();
}
   else
{
      return Update();
 }

}

 public bool Fetch() 
{

        try
        { 
 string sql; 

        sql = "Select * From CurrencyValues  where id= " + id;
        return Populate(sql);
        }
        catch (Exception ex)
        {
            CommonTools.ErrorManager.LogError("CurrencyValuesController", "Fetch", "", ex);
            return false;
        }

    }


private bool Populate(string SQL) 
{

         try
{
           DataRow  records = DataAccessObject.GetOneRow(SQL);

             if (records == null) return false;


    id = (int) records["id"];
    CurrencySymbol = (records["CurrencySymbol"].ToString() == null? "": records["CurrencySymbol"].ToString());
    Year = (int) records["Year"];
    Value = (Double.Parse(records["Value"].ToString()) == null? 0: Double.Parse(records["Value"].ToString()));


             return true;
}
         catch ( Exception ex)
{
             ErrorManager.LogError("clsCurrencyValues", "Populate", "", ex);
             return false;
}
         finally
{
             DataAccessObject.CloseConnection();
}


     }

  private List<DatabaseParameter>  CreateParameterList () 
  {
        try { 
   List<DatabaseParameter> values  = new List<DatabaseParameter>(); 
    if (id == -1)  
  {
    values.Add (new DatabaseParameter( "@MaxId",  DbType.Int16,  null,  true));  
  }
  else    
  {
   values.Add(new DatabaseParameter("id", DbType.Int16, id));  
  }
 
  values.Add (new DatabaseParameter("@CurrencySymbol",DbType.String,CurrencySymbol)); 
  values.Add (new DatabaseParameter("@Year",DbType.Int32,Year)); 
  values.Add (new DatabaseParameter("@Value",DbType.Double,Value)); 
 
 return values;

        }
        catch (Exception ex)
        {
            CommonTools.ErrorManager.LogError("CurrencyValuesController", "CreateParameterList", "", ex);
            return null;
        }
    }


 private bool Insert() 
{
     try
{
         if (id != -1) { return false; }
    DataAccessObject.ExecuteDatabaseTransaction("iCurrencyValues",CreateParameterList()); 


        return true;
    }

     catch (Exception ex )
     {
         ErrorManager.LogError("CurrencyValues", "", "Insert", ex);
         return false;
     }

 }



 private bool Update() 
 {
     try
{

    DataAccessObject.ExecuteDatabaseTransaction("uCurrencyValues",CreateParameterList()); 




        return true;

}
     catch (Exception ex) {
         ErrorManager.LogError("CurrencyValues", "", "Update", ex);
         return false;
     }

 }




 } 

