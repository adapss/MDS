﻿using CommonTools;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace MiraAdmin.ClientStudies
{
    public class ClientStudiesView
    {

        public System.Data.DataTable GetStudyYears()
        {
            try
            {
                string sql = "Select Distinct BaseYear as [Year] from [vwStudiesRoot] order by baseyear desc ";

               

                return CommonTools.DataAccessObject.GetTable(sql);
            }
            catch (Exception ex)
            {
                CommonTools.ErrorManager.LogError("ClientsView", "GetView", "", ex);
                return null;
            }
        }

        public System.Data.DataTable GetUnAssigned(int clientId, List<string> year, string studyName)
        {
            try
            {
             

                IList<string> strings = year;
                string joinedYears = string.Join(",", strings);
                string sql = "exec GetUnAssignedStudies '" + joinedYears + "'," + clientId.ToString() + ",'" + studyName + "'";
                return CommonTools.DataAccessObject.ExecuteProcedure(sql);


               
            }
            catch (Exception ex)
            {
                CommonTools.ErrorManager.LogError("ClientsView", "GetView", "", ex);
                return null;
            }
        }

        public System.Data.DataTable GetAssigned(int clientId, List<string> year, string studyName)
        {
            try
            {
          
                IList<string> strings = year;
                string joinedYears = string.Join(",", strings);
                string sql = "exec [GetAssignedStudies] '" + joinedYears + "'," + clientId.ToString() + ",'" + studyName + "'";
                return CommonTools.DataAccessObject.ExecuteProcedure(sql);


              
            }
            catch (Exception ex)
            {
                CommonTools.ErrorManager.LogError("ClientsView", "GetView", "", ex);
                return null;
            }
        }

    }
}