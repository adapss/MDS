﻿
 public class ClientStudiesModel

{
public ClientStudiesModel()
{

id= -1;
ClientId= -1;
StudyId= -1;
BaseYear= -1;

}
public  int id {get;set;}  
public  int ClientId {get;set;}  
public  int StudyId {get;set;}  
public  int BaseYear {get;set;}  


}

