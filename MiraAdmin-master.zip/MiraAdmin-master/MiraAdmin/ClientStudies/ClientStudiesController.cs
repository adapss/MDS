﻿
using System;
using System.Collections.Generic;
using System.Data;
using CommonTools;





public class ClientStudiesController: ClientStudiesModel

{
 private string _tableName = "ClientStudies";

 public void Delete() 

{
  if (id  == -1)  return; 

 DataAccessObject.Execute("Delete From  ClientStudies where id = " +  id);

 }


 public bool Save()  
{
  if (id  == -1) 

{
 return Insert();
}
   else
{
      return Update();
 }

}

 public bool Fetch() 
{

 string sql; 

        sql = "Select * From ClientStudies  where id= " + id;
        return Populate(sql);


 }


private bool Populate(string SQL) 
{

         try
{
           DataRow  records = DataAccessObject.GetOneRow(SQL);

             if (records == null) return false;


    id = (int) records["id"];
    ClientId = (int) records["ClientId"];
    StudyId = (int) records["StudyId"];
    BaseYear = (int) records["BaseYear"];


             return true;
}
         catch ( Exception ex)
{
             ErrorManager.LogError("clsClientStudies", "Populate", "", ex);
             return false;
}
         finally
{
             DataAccessObject.CloseConnection();
}


     }

  private List<DatabaseParameter>  CreateParameterList () 
  {
   List<DatabaseParameter> values  = new List<DatabaseParameter>(); 
    if (id == -1)  
  {
    values.Add (new DatabaseParameter("@id",  DbType.Int16,  null,  true));  
  }
  else    
  {
   values.Add(new DatabaseParameter("@id", DbType.Int16, id));  
  }
 
  values.Add (new DatabaseParameter("@ClientId",DbType.Int32,ClientId)); 
  values.Add (new DatabaseParameter("@StudyId",DbType.Int32,StudyId)); 
  values.Add (new DatabaseParameter("@BaseYear",DbType.Int32,BaseYear)); 
 
 return values; 
  }


 private bool Insert() 
{
     try
{
         if (id != -1) { return false; }
    DataAccessObject.ExecuteDatabaseTransaction("iClientStudies",CreateParameterList()); 


        return true;
}

     catch (Exception ex )
     {
         ErrorManager.LogError("ClientStudies", "", "Insert", ex);
         return false;
     }

 }



 private bool Update() 
 {
     try
{

    DataAccessObject.ExecuteDatabaseTransaction("uClientStudies",CreateParameterList()); 




        return true;

}
     catch (Exception ex) {
         ErrorManager.LogError("ClientStudies", "", "Update", ex);
         return false;
     }

 }




 } 

