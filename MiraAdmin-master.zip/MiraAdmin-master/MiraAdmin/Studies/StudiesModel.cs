﻿
 public class StudiesModel

{
        public StudiesModel()
        {
                Id= -1;
                Study = "";
                //GroupId= -1;
                Core= -1;
                 StudyGroup = new StudyGroupController();
        }
        public  int Id {get;set;}  
        public  string  Study {get;set;}
        public StudyGroupController StudyGroup { get; set; }
        //public  int GroupId {get;set;}  
        public  int Core {get;set;} 
    
    public string CoreDisplay { get; set; }
         public string GroupName
        {
            get
            {
                return StudyGroup.GroupName;
            }
        }



}

