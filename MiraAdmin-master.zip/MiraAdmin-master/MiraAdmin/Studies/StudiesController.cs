﻿using System.Collections.Generic;
using System.Data;
using System;

  using CommonTools;





public class StudiesController: StudiesModel

{
 private string _tableName = "Studies";

 public void Delete() 

{
  if (Id  == -1)  return; 

 DataAccessObject.Execute("Delete From  " + _tableName + " where id = " +  Id);

 }


 public bool Save()  
{
  if (Id  == -1) 

{
 return Insert();
}
   else
{
      return Update();
 }

}

 public bool Fetch() 
{

 string sql; 

        sql = "Select * From Studies  where Id= " + Id;
        return Populate(sql);


 }


private bool Populate(string SQL) 
{

         try
{
           DataRow  records = DataAccessObject.GetOneRow(SQL);

             if (records == null) return false;

            Id = (int) records["Id"];
            Study = (records["Study"].ToString() == null? "": records["Study"].ToString());
           // StudyGroup.Id = (int) records["GroupId"];
            Core = (int) records["Core"];
           // StudyGroup.Fetch();
           

             return true;
}
         catch ( Exception ex)
{
             ErrorManager.LogError("StudiesController", "Populate", "", ex);
             return false;
}
         finally
{
             DataAccessObject.CloseConnection();
}


     }

          private List<DatabaseParameter>  CreateParameterList () 
          {
                   List<DatabaseParameter> values  = new List<DatabaseParameter>(); 
                    if (Id == -1)  
                          {
                            values.Add (new DatabaseParameter( "@Id",  DbType.Int16,  null,  true));  
                          }
                          else    
                          {
                           values.Add(new DatabaseParameter("@Id", DbType.Int16, Id));  
                          }
 
                  values.Add (new DatabaseParameter("@Study",DbType.String,Study)); 
              //    values.Add (new DatabaseParameter("@GroupId",DbType.Int32, StudyGroup.Id)); 
                  values.Add (new DatabaseParameter("@Core",DbType.Int32,Core)); 
 
                 return values; 
          }


         private bool Insert() 
        {
             try
        {
                 if (Id != -1) { return false; }
            DataAccessObject.ExecuteDatabaseTransaction("iStudies",CreateParameterList()); 


                return true;
        }

             catch (Exception ex )
             {
                 ErrorManager.LogError("Studies", "", "Insert", ex);
                 return false;
             }

         }

         private bool Update() 
             {
                 try
            {

                 DataAccessObject.ExecuteDatabaseTransaction("uStudies",CreateParameterList()); 


                 return true;

            }
                 catch (Exception ex) {
                     ErrorManager.LogError("Studies", "", "Update", ex);
                     return false;
                 }

             }                                                                      




 } 

