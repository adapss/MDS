﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using CommonTools;
using MiraAdmin.WebTools;

namespace MiraAdmin.Studies
{
    public partial class Index : System.Web.UI.Page
    {
        private  StudiesView data = new StudiesView();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                ProcessLoadData();
            }
        }



     
     

        private void ProcessLoadData()
        {
            try

            {
                dtgCore.DataSource = data.GetCoreStudies(txtSearchCore.Text);
                dtgCore.DataBind();

                dtgNonCore.DataSource = data.GetNonCoreStudies(txtSearchNonCore.Text);
                dtgNonCore.DataBind();

            }
            catch (Exception ex)
            {
                ErrorManager.LogError("Default.aspx", "Populate", "", ex);

            }
        }
    


     

        protected void btnNew_Click(object sender, EventArgs e)
        {
            WebHelper.CurrentValueId = -1;
            Response.Redirect("Edit.aspx");
        }


        public void SelectItem(object src, DataGridCommandEventArgs e)
        {
            if (e.Item.ItemIndex < 0) return;
            if (e.Item.Cells.Count < 2) return;
            string id = e.Item.Cells[0].Text;
            WebHelper.CurrentValueId = int.Parse(id);
            Response.Redirect("Edit.aspx");

        }

        protected void chkAll_AllUnassigned(object sender, EventArgs e)
        {
            bool status = chkAllUnassigned.Checked;

            foreach (DataGridItem di in dtgNonCore.Items)
            {
                HtmlInputCheckBox chkBx = (HtmlInputCheckBox)di.FindControl("ItemId");
                chkBx.Checked = status;
            }
        }

        protected void chkAll_AllAssigned(object sender, EventArgs e)
        {
            bool status = chkAllAssigned.Checked;

            foreach (DataGridItem di in dtgCore.Items)
            {
                HtmlInputCheckBox chkBx = (HtmlInputCheckBox)di.FindControl("ItemId");
                chkBx.Checked = status;
            }
        }



        protected void btnSearchUnassigned_Click(object sender, EventArgs e)
        {
            ProcessLoadData();
            btnClearUnassigned.Visible = true;
        }

      

        protected void btnSearchAssigned_Click(object sender, EventArgs e)
        {
            ProcessLoadData();
            btnCleaAssigned.Visible = true;
        }

        public List<string> GetSelectedNonCoreStudies()
        {
            List<string> selected = new List<string>();


            foreach (DataGridItem di in dtgNonCore.Items)
            {
                HtmlInputCheckBox chkBx = (HtmlInputCheckBox)di.FindControl("ItemId");
                if (chkBx != null && chkBx.Checked)
                {
                    Label lbl = (Label)di.FindControl("Id");
                    selected.Add(lbl.Text);
                }
            }

            return selected;
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            var allChecked = GetSelectedNonCoreStudies();
            
                foreach (var item in allChecked)
                {
                    StudiesController studiesController = new StudiesController();
                    studiesController.Id = Int32.Parse(item);
                    studiesController.Fetch();
                    studiesController.Core = 1;
                    studiesController.Save();
                }

            ProcessLoadData();
        }


        public List<string> GetSelectedCoreStudies()
        {
            List<string> selected = new List<string>();


            foreach (DataGridItem di in dtgCore.Items)
            {
                HtmlInputCheckBox chkBx = (HtmlInputCheckBox)di.FindControl("ItemId");
                if (chkBx != null && chkBx.Checked)
                {
                    Label lbl = (Label)di.FindControl("Id");
                    selected.Add(lbl.Text);
                }
            }

            return selected;
        }


        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {

            var allChecked = GetSelectedCoreStudies();

            foreach (var item in allChecked)
            {
                StudiesController studiesController = new StudiesController();
                studiesController.Id = Int32.Parse(item);
                studiesController.Fetch();
                studiesController.Core = 0;
                studiesController.Save();
            }

            ProcessLoadData();

        }

        protected void btnSearchAssigned_Click1(object sender, EventArgs e)
        {
            ProcessLoadData();
        }

        protected void btnClearUnassigned_Click(object sender, EventArgs e)
        {
            txtSearchNonCore.Text = "";
            btnClearUnassigned.Visible = false;
            ProcessLoadData();
        }

        protected void btnCleaAssigned_Click(object sender, EventArgs e)
        {
            txtSearchCore.Text = "";
            btnCleaAssigned.Visible = false;
            ProcessLoadData();
        }
    }
}