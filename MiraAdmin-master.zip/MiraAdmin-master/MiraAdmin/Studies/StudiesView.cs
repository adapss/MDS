﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace MiraAdmin.Studies
{
    public class StudiesView
    {

        public List<StudiesModel> list = new List<StudiesModel>();
        public System.Data.DataTable GetList()
        {
            return CommonTools.DataAccessObject.GetTable("select studies.Id,Study,GroupId, core, case when Core = 0 then '' else 'x' end as CoreDisplay,GroupName from studies, StudyGroup where studies.GroupId = StudyGroup.Id");
        }

        public System.Data.DataTable GetCoreStudies(string studyName)
        {
            
            string sql = "select studies.Id,Study from studies where core = 1";
            if (!String.IsNullOrWhiteSpace(studyName))
            {
                sql = sql + " and Study like '" + studyName + "%'";
            }
                       
            return CommonTools.DataAccessObject.GetTable(sql);
        }

        public System.Data.DataTable GetNonCoreStudies(string studyName)
        {

           
          string  sql = "exec GetNonCoreStudies '" + studyName + "%'";
            return CommonTools.DataAccessObject.ExecuteProcedure(sql);
        }

        public bool PopulateList()
        {
            var data = GetList();
            list = new List<StudiesModel>();
            foreach (System.Data.DataRow records in data.Rows)
            {
                StudiesModel newItem = new StudiesModel();
                newItem.Id = int.Parse(records["Id"].ToString());
                newItem.Study = (records["Study"].ToString() == null ? "" : records["Study"].ToString());
                newItem.StudyGroup.Id = int.Parse(records["GroupId"].ToString()); 
                newItem.CoreDisplay = (records["CoreDisplay"].ToString() == null ? "" : records["CoreDisplay"].ToString()); 
                newItem.Core = int.Parse(records["Core"].ToString());
                list.Add(newItem);
            }
            return true;

        }
    }
}