﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MiraAdmin.WebTools;
using MiraAdmin.StudyGroup;

namespace MiraAdmin.Studies
{
    public partial class Edit : System.Web.UI.Page
    {
        StudiesController value;
        List<StudyGroupModel> groupNameList;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack) return;
            txtStudyName.Attributes.Add("onkeydown", "javascript:ChangeSize()");
           
            Populate();

        }

        private void Populate()
        {
            groupNameList = new List<StudyGroupModel>();
            StudyGroupView groups = new StudyGroupView();
            if (groups.PopulateList())
                groupNameList = groups.list;

            WebTools.WebHelper.BindControl(ddlGroupName, groups.GetGroups(), "GroupName", "Id");
            value = new StudiesController();
            value.Id = WebHelper.CurrentValueId;
            if (!value.Fetch()) return;

            WebTools.WebHelper.AddSelectedValue(ddlGroupName, value.StudyGroup.Id);
            txtStudyName.Text = value.Study.ToString();
            txtStudyName.Width = txtStudyName.Text.Length * 8;
            chkCore.Checked = (value.Core == 1);
           



        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            value = new StudiesController();

            value.Id = WebTools.WebHelper.CurrentValueId;
            value.StudyGroup.Id = int.Parse( ddlGroupName.SelectedValue);
            value.Study = txtStudyName.Text;
            value.Core = (chkCore.Checked ? 1 : 0);

            if (value.Save())
            {
                lblInformation.Text = "Record saved";
            }
            else
            {
                lblInformation.Text = "Unable to save  record";
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("Index.aspx");
        }
    }
}