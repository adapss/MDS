﻿using System;
using System.Data;

namespace CommonTools
{
    public class DatabaseParameter
    {


        public string Name;
        public DbType Type;
        public Object Value;
        public bool Output;

        public DatabaseParameter(string newName, DbType newType, Object newValue, bool isOutPut = false)
        {

            Name = newName;
            Type = newType;
            Value = newValue;
            Output = isOutPut;

        }

    }
}