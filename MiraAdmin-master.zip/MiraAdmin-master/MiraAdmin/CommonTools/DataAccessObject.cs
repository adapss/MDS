﻿using System;
using System.Collections.Generic;
using System.Data;
//using System.Data.OleDb;
using System.Configuration;
using System.Data.SqlClient;


namespace CommonTools
{
    public sealed class DataAccessObject
    {

        private static SqlConnection _dbConnection;
        private static string _connectionString = System.Configuration.ConfigurationSettings.AppSettings["connectionstring"];
        private static bool _keepOpen = false;

        private static string _dbConnectionString = "";
        private static string _objectName = "DataAccessObject";



        public static string DbConnectionString
        {
            get { return _dbConnectionString; }
            set { _dbConnectionString = value; }
        }

        public static bool KeepOpen
        {
            get { return _keepOpen; }
            set { _keepOpen = value; }
        }



        private static void ParseConnectionString(string userId, string database, string server, string password)
        {

            if (userId.Equals("sa"))
            {
                _dbConnectionString =
                    String.Concat("Persist Security Info=False;User ID=", userId, ";Password= ", password, ";Initial Catalog=", database, ";Data Source=", server, ";");
            }
            else
            {
                _dbConnectionString = String.Concat("Initial Catalog=", database, ";Data Source=", server, ";Integrated Security=SSPI;");
            }
        }



        public static Boolean OpenConnection()
        {

            try
            {
                if (_dbConnectionString == null || _dbConnectionString.Trim().Equals(""))
                {

                    _dbConnectionString = System.Configuration.ConfigurationSettings.AppSettings["ConnectionString"];
                }

                if (_dbConnectionString == null || _dbConnectionString.Trim().Equals(""))
                {
                    _dbConnectionString = ConfigurationManager.ConnectionStrings["sql-db-connection"].ConnectionString;
                }

                if (_dbConnection?.State == ConnectionState.Open)
                {
                    return true;
                }

                _dbConnection = new SqlConnection(_dbConnectionString);
                _dbConnection.Open();
                if (_dbConnection.State == ConnectionState.Open)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                ErrorManager.LogError(_objectName, "", "OpenConnection", ex);
                return false;
            }
        }

        public static void Execute(string sql)
        {
            try
            {
                if (OpenConnection() == false)
                {
                    return;
                }

                SqlCommand dbCommand = new SqlCommand(sql, _dbConnection);
                dbCommand.ExecuteNonQuery();
                dbCommand.Connection.Close();
                dbCommand.Dispose();


            }
            catch (Exception ex)
            {
                ErrorManager.LogError(_objectName, "", "Execute", ex);

            }
        }

        public static SqlDataReader ExecuteReader(string sql)
        {

            try
            {
                if (OpenConnection() == false)
                    return null;

                SqlCommand dbCommand = new SqlCommand(sql, _dbConnection);

                var data = dbCommand.ExecuteReader(CommandBehavior.CloseConnection);
                dbCommand.Dispose();
                return data;

            }
            catch (Exception ex)
            {
                ErrorManager.LogError(_objectName, "", "ExecuteReader", ex);
                return null;
            }
        }


        public static List<SqlParameter> CreateParameterList(List<DatabaseParameter> inputList)


        {
            try
            {

                List<SqlParameter> parameters = new List<SqlParameter>();

                foreach (var item in inputList)
                {
                    var parameter = CreateParameter(item);
                    parameters.Add(parameter);
                }

                return parameters;
            }
            catch (Exception ex)
            {
                ErrorManager.LogError(_objectName, "", "CreateParameterList", ex);
                return null;
            }

        }


        private static SqlParameter CreateParameter(DatabaseParameter item)
        {
            var parameter = item.Output ? CreateOutputParameter(item.Name, item.Type) : CreateInputParameter(item.Name, item.Type, item.Value);
            return parameter;
        }

        public static SqlParameter CreateInputParameter(string name, DbType type, Object value)
        {

            SqlParameter param = new SqlParameter();

            param.DbType = type;
            if (param.DbType == DbType.String)
            {
                if (value != DBNull.Value && value != null)
                {
                    param.Size = value.ToString().Length;
                    value = CleanString(value.ToString());
                }
                else
                {
                    param.Size = 10;
                }
            }
            else
            {
                param.Value = value;
            }
            param.Value = value;
            param.ParameterName = name;
            param.Direction = ParameterDirection.Input;
            return param;


        }

        public static SqlParameter CreateOutputParameter(string name, DbType type)
        {
            SqlParameter param = new SqlParameter();

            param.DbType = type;
            if (param.DbType == DbType.AnsiString)
            {
                param.Value = "";
            }
            else if (param.DbType == DbType.VarNumeric)
            {
                param.Value = 0;
            }
            param.ParameterName = name;
            param.Direction = ParameterDirection.Output;

            return param;

        }
        public static DataTable ExecuteStoredProcedure(string procedureName, List<DatabaseParameter> databaseParameters)
        {

            try
            {

                if (OpenConnection() == false)
                    return null;

                List<SqlParameter> parameters = new List<SqlParameter>();

                parameters = CreateParameterList(databaseParameters);

                SqlCommand dbCommand = new SqlCommand(procedureName, _dbConnection);
                dbCommand.CommandType = CommandType.StoredProcedure;

                foreach (SqlParameter oParam in parameters)
                {
                    if (oParam != null)
                    {
                        if ((oParam.Direction == ParameterDirection.Output || oParam.Direction == ParameterDirection.InputOutput) && oParam.Value != null)
                        {
                            oParam.Value = DBNull.Value;
                        }
                        dbCommand.Parameters.Add(oParam);
                    }
                }


                DataSet info = new DataSet();
                SqlDataAdapter data = new SqlDataAdapter(dbCommand);
                data.Fill(info);


                dbCommand.Dispose();
                if (_keepOpen == false)
                    CloseConnection();

                return info.Tables[0];
            }

            catch (Exception ex)
            {
                ErrorManager.LogError(_objectName, "", "ExecuteStoredProcedure", ex);
                return null;
            }

        }

        public static void StoredProcedure(string procedureName, SqlParameter[] parameters)
        {

            try
            {

                if (OpenConnection() == false)
                    return;

                SqlCommand dbCommand = new SqlCommand(procedureName, _dbConnection);
                dbCommand.CommandType = CommandType.StoredProcedure;

                // SqlParameter oParam;

                for (int index = 0; index < parameters.Length; index++)
                {
                    SqlParameter oParam = parameters[index];
                    if (oParam != null)
                    {
                        if ((oParam.Direction == ParameterDirection.InputOutput ||
                             (oParam.Direction == ParameterDirection.Input) && oParam.Value == null))
                        {
                            oParam.Value = DBNull.Value;
                        }
                        dbCommand.Parameters.Add(oParam);
                    }
                }

                dbCommand.ExecuteNonQuery();
                dbCommand.Dispose();
                if (_keepOpen == false)
                    CloseConnection();
            }

            catch (Exception ex)
            {
                ErrorManager.LogError(_objectName, "", "StoredProcedure", ex);

            }

        }

        public static void CloseConnection()
        {
            try
            {
                _dbConnection.Close();
            }
            catch (Exception e)
            {
            }
        }

        

        public static DataTable PopulateData(string procedureName, SqlParameter[] parameters)
        {

            try
            {

                if (OpenConnection() == false)
                    return null;

                SqlCommand dbCommand = new SqlCommand(procedureName, _dbConnection);
                dbCommand.CommandType = CommandType.StoredProcedure;

                // SqlParameter oParam;

                for (int index = 0; index < parameters.Length; index++)
                {
                    SqlParameter oParam = parameters[index];
                    if (oParam != null)
                    {
                        if ((oParam.Direction == ParameterDirection.InputOutput ||
                             (oParam.Direction == ParameterDirection.Input) && oParam.Value == null))
                        {
                            oParam.Value = DBNull.Value;
                        }
                        dbCommand.Parameters.Add(oParam);
                    }
                }

                var reader = dbCommand.ExecuteReader();
                DataTable data = new DataTable();
                data.Load(reader);

                dbCommand.Dispose();
                if (_keepOpen == false)
                    CloseConnection();
                return data;
            }

            catch (Exception ex)
            {
                ErrorManager.LogError(_objectName, "", "PopulateData", ex);
                return null;

            }

        }

        public static SqlDataAdapter GetDataAdapter(string sql)
        {
            try
            {
                if (OpenConnection() == false)
                    return null;

                SqlCommand dbCommand = new SqlCommand(sql, _dbConnection);

                dbCommand.CommandTimeout = 18000;

                SqlDataAdapter data = new SqlDataAdapter(dbCommand);
                return data;

            }
            catch (Exception ex)
            {
                ErrorManager.LogError("DataAccess", "", "GetDataAdapter", ex);
                return null;
            }

        }

        public static void KillConnection()
        {
            try
            {
                _keepOpen = false;
                CloseConnection();
            }
            catch
            {
            }
        }

        public static DataSet GetDataSet(string sql)
        {

            try
            {
                if (OpenConnection() == false)
                    return null;

                SqlCommand dbCommand = new SqlCommand(sql, _dbConnection);
                SqlDataAdapter data;
                DataSet info = new DataSet();
                dbCommand.CommandTimeout = 18000;

                data = new SqlDataAdapter(dbCommand);
                data.Fill(info);

                dbCommand.Dispose();
                data.Dispose();

                if (_keepOpen == false)
                    CloseConnection();

                return info;

            }
            catch (Exception ex)
            {
                ErrorManager.LogError(_objectName, "", "GetDataSet", ex);
                return null;
            }

        }

        public static int ExtractIntValue(object item)
        {
            if (String.IsNullOrEmpty(item?.ToString())) return -1;
            int value;
            bool result = Int32.TryParse(item.ToString(), out value);
            return result == true ? value : -1;

        }

        public static DateTime ExtractDateValue(object item)
        {
            if (String.IsNullOrEmpty(item?.ToString())) return new DateTime(1900, 01, 01);
            DateTime value;
            bool result = DateTime.TryParse(item.ToString(), out value);
            return result == true ? value : new DateTime(1900, 01, 01);
        }

        public static double ExtractDoubleValue(object item)
        {
            if (String.IsNullOrEmpty(item?.ToString())) return -1;
            double value;
            bool result = double.TryParse(item.ToString(), out value);
            return result == true ? value : -1;

        }

        public static String ExtractStringValue(object item)
        {
            if (String.IsNullOrEmpty(item?.ToString())) return "";

            return item.ToString();

        }

        public static DataSet GetDataSet(string sql, string tableName)
        {
            try
            {

                if (OpenConnection() == false)
                    return null;

                SqlCommand dbCommand = new SqlCommand(sql, _dbConnection);
                SqlDataAdapter data;
                DataSet info = new DataSet();
                dbCommand.CommandTimeout = 18000;

                data = new SqlDataAdapter(dbCommand);
                data.Fill(info, tableName);

                dbCommand.Dispose();
                data.Dispose();

                if (_keepOpen == false)
                    CloseConnection();

                if (info.Tables.Count == 0)
                    return null;
                return info;


            }
            catch (Exception ex)
            {
                ErrorManager.LogError(_objectName, "", "GetDataSet", ex);
                return null;
            }

        }

        public static DataTable GetTable(string sql)
        {
            try
            {

                DataSet oData;

                oData = GetDataSet(sql);
                if (oData == null) return null;
                if (oData.Tables.Count == 0)
                    return null;
                return oData.Tables[0];


            }
            catch (Exception ex)
            {
                ErrorManager.LogError(_objectName, "", "GetTable", ex);
                return null;
            }

        }

        public static DataRow GetOneRow(string sql)
        {
            try
            {
                var oData = GetDataSet(sql);
                if (oData.Tables.Count == 0)
                    return null;
                if (oData.Tables[0].Rows.Count == 0)
                    return null;
                return oData.Tables[0].Rows[0];

            }
            catch (Exception ex)
            {
                ErrorManager.LogError(_objectName, "", "GetOneRow", ex);
                return null;
            }
        }


        private void ExecuteNonQuery(string sql)
        {
            try
            {
                if (OpenConnection() == false)
                    return;

                SqlCommand dbCommand = new SqlCommand(sql, _dbConnection);
                dbCommand.ExecuteNonQuery();
                if (_keepOpen == false)
                    CloseConnection();


            }
            catch (Exception ex)
            {
                ErrorManager.LogError(_objectName, "", "GetDataSet", ex);

            }

        }

        public static string CleanString(string value = "")
        {
            if (value == null)
                return null;
            if (value.Length == 0)
                return null;

            // var replace = value.Replace("'", "''");
            var replace = value.Replace(";", "");
            //  replace = replace.Replace("Select", "'Select'");
            replace = replace.Replace("Delete", "'Delete'");
            replace = replace.Replace("Update", "'Update'");
            return replace;

        }

        //public static SqlParameter CreateInputParameter(string name, DbType type, object value)
        //{
        //    SqlParameter param = new SqlParameter();

        //    param.DbType = type;
        //    if (param.DbType == DbType.String)
        //    {
        //        if (value != DBNull.Value && value != null)               
        //            param.Size = value.ToString().Length;               
        //        else
        //            param.Size = 10;
        //        param.Value = CleanString(value.ToString());
        //        param.ParameterName = name;
        //        param.Direction = ParameterDirection.Input;
        //    }

        //    return param;

        //}

        public static SqlParameter CreateOutPutParameter(string name, DbType type)
        {
            SqlParameter param = new SqlParameter();

            param.DbType = type;
            if (param.DbType == DbType.AnsiString)
                param.Value = "";
            else
            {
                if (param.DbType == DbType.VarNumeric)
                    param.Value = 0;
            }
            param.ParameterName = name;
            param.Direction = param.Direction = ParameterDirection.Output;
            return param;
        }

        ~DataAccessObject()
        {
            try
            {
                CloseConnection();
            }
            catch (Exception)
            {
            }

        }

        public static DataTable ExecuteProcedure(string sql)
        {
            try
            {

                if (OpenConnection() == false)
                    return null;

                SqlCommand dbCommand = new SqlCommand(sql, _dbConnection);

                var reader = dbCommand.ExecuteReader();
                DataTable data = new DataTable();
                data.Load(reader);

                dbCommand.Dispose();
                if (_keepOpen == false)
                    CloseConnection();
                return data;
            }

            catch (Exception ex)
            {
                ErrorManager.LogError(_objectName, "", "PopulateData", ex);
                return null;

            }
        }

        public static DataTable ProcessStoredProcedure(string storedProcedureName, List<DatabaseParameter> paramenterList)
        {
            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters = CreateParameterList(paramenterList);
                return PopulateData(storedProcedureName, parameters.ToArray());

            }
            catch (Exception ex)
            {
                ErrorManager.LogError(_objectName, "ExecuteStoredProcedure", "", ex, storedProcedureName);
                return null;
            }

        }

        public static List<SqlParameter> ExecuteDatabaseTransaction(string storedProcedureName, List<DatabaseParameter> paramenterList)
        {

            try
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters = CreateParameterList(paramenterList);
                StoredProcedure(storedProcedureName, parameters.ToArray());
                return parameters;
            }
            catch (Exception ex)
            {
                ErrorManager.LogError(_objectName, "ExecuteDatabaseTransaction", "", ex, storedProcedureName);
                return null;
            }


        }





    }
}
