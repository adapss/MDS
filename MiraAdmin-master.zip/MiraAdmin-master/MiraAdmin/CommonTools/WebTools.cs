﻿
using System;
using System.Collections.Generic;

public sealed class GeneralTools
{

    public static List<string> TheMonths;

    private static string _userId;

    public GeneralTools()
    {
        TheMonths = new List<string>();

        TheMonths.Add("");
        TheMonths.Add("January");
        TheMonths.Add("February");
        TheMonths.Add("March");
        TheMonths.Add("April");
        TheMonths.Add("May");
        TheMonths.Add("June");
        TheMonths.Add("July");
        TheMonths.Add("August");
        TheMonths.Add("September");
        TheMonths.Add("October");
        TheMonths.Add("November");
        TheMonths.Add("December");

    }

   

    public static string UserId
    {
        get
        {
            return _userId;
        }
        set
        {
            _userId = value;
        }
    }


    public static string CleanString(string sValue)
    {
        // This function cleans all input text from the site
        // looks for malicious input and removes it.
        sValue = sValue.Replace(",", "''");
        sValue = sValue.Replace(";", "");
        sValue = sValue.Replace("SELECT", "");
        sValue = sValue.Replace("INSERT", "");
        sValue = sValue.Replace("DELETE", "");
        sValue = sValue.Replace("FROM", "");
        sValue = sValue.Replace("CREATE", "");
        sValue = sValue.Replace("ALTER", "");

        return sValue;
    }



    public static string ParseTextBoxContent(string content)

    {
        System.IO.StringReader Reader;
        string Parsed = "";

        Reader = new System.IO.StringReader(content);

        do
        {
            if (Parsed.Length == 0)
            {
                Parsed = Reader.ReadLine();
            }
            else
            {
                Parsed = Parsed + "<br>" + Reader.ReadLine();
            }

        } while (Reader.Peek() > -1);

        return Parsed;

    }

    public static string StripImageFromHeader(string header)
    {
        int headerLength;
        string result;

        if (header.IndexOf("&nbsp;") > -1)
        {
            headerLength = header.IndexOf("&nbsp;");
            if (header.IndexOf("</b>") > -1)
            {
                result = header.Substring(0, headerLength);
            }
            else
            {
                result = header.Substring(0, headerLength) + "</b>";
            }
        }
        else
        {
            result = header;
        }
        return result;
    }


    public static string FormatDate(DateTime ThisDate)
    {
        return ThisDate.ToString("MM/dd/yyyy");

    }



}