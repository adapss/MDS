﻿using System;
using System.IO;
using System.Linq;


//=======================================================================
//
//     Author: Ana Del Campo
//    Created: February 2014
//    Purpose: Manages Sytem Errors
//
//=======================================================================

namespace CommonTools
{
    public static class ErrorManager
    {
        private static string _fileName = "";


        public static string[] Msgs;

        public static void Log(string message)
        {
            _fileName = System.AppDomain.CurrentDomain.BaseDirectory + "data\\logs\\Log.txt";

            if (Directory.Exists(System.AppDomain.CurrentDomain.BaseDirectory + "Data") == false)
            {
                Directory.CreateDirectory(System.AppDomain.CurrentDomain.BaseDirectory + "Data");
            }

            if (Directory.Exists(System.AppDomain.CurrentDomain.BaseDirectory + "Data\\logs") == false)
            {
                Directory.CreateDirectory(System.AppDomain.CurrentDomain.BaseDirectory + "Data\\logs");
            }

            if (System.IO.File.Exists(_fileName) == true)
            {
                FileInfo fileInformation = new FileInfo(_fileName);

                if (fileInformation.Length > 100000)
                {
                    string newFileName = System.AppDomain.CurrentDomain.BaseDirectory + "data\\logs\\log.old";
                    if (System.IO.File.Exists(newFileName) == true)
                    {
                        System.IO.File.Delete(newFileName);
                    }
                    try
                    {
                        newFileName = null;
                    }
                    catch
                    {
                    }
                }
            }



            FileStream fs = new FileStream(_fileName, FileMode.OpenOrCreate, FileAccess.Write);
            StreamWriter Stream = new StreamWriter(fs);

            try
            {
                message = System.DateTime.Now + " | " + message;
                //Save the message to file
                Stream.BaseStream.Seek(0, SeekOrigin.End);
                Stream.WriteLine(message);
            }
            catch
            {
            }
            finally
            {
                Stream.Close();
            }


        }

        public static void LogError(string moduleName, string objectName, string methodName, Exception sysException, string custom = "")
        {
            _fileName = System.AppDomain.CurrentDomain.BaseDirectory + "data\\logs\\Log.txt";

            if (Directory.Exists(System.AppDomain.CurrentDomain.BaseDirectory + "Data") == false)
            {
                Directory.CreateDirectory(System.AppDomain.CurrentDomain.BaseDirectory + "Data");
            }

            if (Directory.Exists(System.AppDomain.CurrentDomain.BaseDirectory + "Data\\logs") == false)
            {
                Directory.CreateDirectory(System.AppDomain.CurrentDomain.BaseDirectory + "Data\\logs");
            }

            if (System.IO.File.Exists(_fileName) == true)
            {
                FileInfo fileInformation = new FileInfo(_fileName);

                if (fileInformation.Length > 100000)
                {
                    string newfileName = System.AppDomain.CurrentDomain.BaseDirectory + "data\\logs\\log.old";
                    if (System.IO.File.Exists(newfileName) == true)
                    {
                        System.IO.File.Delete(newfileName);
                    }
                    try
                    {
                        newfileName = null;
                    }
                    catch
                    {
                    }
                }
            }



            FileStream fs = new FileStream(_fileName, FileMode.OpenOrCreate, FileAccess.Write);
            StreamWriter stream = new StreamWriter(fs);

            try
            {

                string message = "";

                message = System.DateTime.Now + " | Error:  " + sysException.GetType().ToString() + " " + sysException.Message + " | At " + moduleName + " " + objectName + " " + methodName + " " + custom;


                stream.BaseStream.Seek(0, SeekOrigin.End);
                stream.WriteLine(message);
            }
            catch
            {
            }
            finally
            {
                stream.Close();
            }


        }


        public static string GetExceptionDetails(this Exception exception)
        {
            var properties = exception.GetType()
                                    .GetProperties();
            var fields = properties
                             .Select(property => new
                             {
                                 Name = property.Name,
                                 Value = property.GetValue(exception, null)
                             })
                             .Select(x => String.Format(
                                 "{0} = {1}",
                                 x.Name,
                                 x.Value != null ? x.Value.ToString() : String.Empty
                             ));
            return String.Join("\n", fields);
        }
    }
}
